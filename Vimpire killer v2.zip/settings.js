/*
┏━━━━━━━━━━━━━━━┓
┃     𝐉𝐀𝐌𝐄𝐒𝐓𝐄𝐂𝐇
┣━━━━━━━━━━━━━━━┛
┃whatsapp : +254785016388
┃owner : james
┃base : vimpire killer 
┃best friend : ibrahim / trashcore dev
┃helper : my brain😂😂
┃maintainer : james
┃deals : t.me/jamespydev
┃pterodactyl hosting buy from james dev
┗━━━━━━━━━━━━━━━┛
*/
const fs = require('fs')

// >~~~~~~~~~~ Owner Setting ~~~~~~~~~~~< //
global.owner = "254785016388"
global.ownername = "james"
global.botname = "vimpire killer"
global.footer = "james moder"
global.packname = "fuck you"

// >~~~~~~~~~~ System Setting ~~~~~~~~~~~< //
global.version = "VERSION 2.0"
global.idch = "12036390490@newsletter"
global.prefa = ["", "/"]

// >~~~~~~~~~~ Thumbnail Setting ~~~~~~~~~~~< //
global.thumb = "https://files.catbox.moe/uy0qod.jpg"

// >~~~~~~~~~~ Message Setting ~~~~~~~~~~~< //
global.mess = {
owner: "-[ *ACCESS DENIED* ]-\n> *_You cannot use this feature because you are not the Owner!_*",  
ownerprem: "-[ *ACCESS DENIED* ]-\n> *_You cannot use this feature because you are not the Owner & a Premium User!_*"
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
